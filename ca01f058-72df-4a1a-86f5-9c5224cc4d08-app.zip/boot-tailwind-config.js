// Tailwind runtime config (CDN mode)
(function(){
  window.tailwind = window.tailwind || {};
  window.tailwind.config = {
    darkMode: 'class',
    theme: { extend: {} }
  };
})();
