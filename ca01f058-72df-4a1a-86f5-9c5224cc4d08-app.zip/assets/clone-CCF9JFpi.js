import{b as r}from"./graph-DiIne0Vq.js";var e=4;function a(o){return r(o,e)}export{a as c};
