var w=(s,d,r)=>new Promise((y,b)=>{var g=a=>{try{n(r.next(a))}catch(l){b(l)}},m=a=>{try{n(r.throw(a))}catch(l){b(l)}},n=a=>a.done?y(a.value):Promise.resolve(a.value).then(g,m);n((r=r.apply(s,d)).next())});import{r as c,A as M,j as e,C as o,B as x}from"./index-BkIQX736.js";import{T as F}from"./TextArea-D4AMfUwQ.js";import{a as S}from"./arabicNumerals-DLyZyag4.js";import{F as P,a as A,b as C,c as D,d as O}from"./index-CjB4vxPV.js";const $=()=>{var v,k;const s=c.useContext(M),[d,r]=c.useState(""),[y,b]=c.useState(!1),[g,m]=c.useState("edit"),[n,a]=c.useState(null),[l,h]=c.useState(!1),[u,j]=c.useState(!1),L=((v=s==null?void 0:s.currentEmployee)==null?void 0:v.role)==="مدير";c.useEffect(()=>{f()},[]);const f=()=>{try{const t=localStorage.getItem("privacyHtml");r(t||p());const i=localStorage.getItem("privacyLastUpdated");i&&a(new Date(i))}catch(t){console.error("خطأ في تحميل محتوى سياسة الخصوصية:",t),r(p())}},p=()=>`
      <div class="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/30 dark:to-indigo-900/30 p-6 rounded-xl border-r-4 border-blue-500 mb-6">
        <p class="text-blue-900 dark:text-blue-200 leading-relaxed">
          <span class="font-bold text-blue-800 dark:text-blue-300">مقدمة:</span> يرجى قراءة هذه السياسة بعناية لفهم كيفية جمع المعلومات واستخدامها وحمايتها 
          عند تصفحك واستخدامك للموقع الإلكتروني لمديرية المالية في محافظة حلب.
        </p>
      </div>

      <section class="mb-8">
        <h2 class="text-2xl font-bold bg-gradient-to-r from-gray-800 to-gray-900 dark:from-white dark:to-gray-200 bg-clip-text text-transparent mb-4">
          1. المعلومات التي نجمعها
        </h2>
        <div class="space-y-6">
          <div class="bg-white dark:bg-gray-800 p-5 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm">
            <h3 class="text-lg font-semibold text-indigo-700 dark:text-indigo-300 mb-3">المعلومات الشخصية:</h3>
            <ul class="list-disc pr-6 space-y-2 text-gray-700 dark:text-gray-300">
              <li>الاسم الكامل والهوية الوطنية</li>
              <li>البريد الإلكتروني وأرقام الهاتف</li>
              <li>العنوان والبيانات الديموغرافية</li>
              <li>تفاصيل الاستعلامات والشكاوى المقدمة</li>
              <li>الملفات والوثائق المرفوعة</li>
            </ul>
          </div>
        </div>
      </section>

      <section class="mb-8">
        <h2 class="text-2xl font-bold bg-gradient-to-r from-gray-800 to-gray-900 dark:from-white dark:to-gray-200 bg-clip-text text-transparent mb-4">
          2. كيفية استخدام المعلومات
        </h2>
        <div class="bg-green-50 dark:bg-green-900/30 p-5 rounded-lg border border-green-200 dark:border-green-700">
          <p class="text-green-800 dark:text-green-200">
            نستخدم المعلومات المجمعة لتقديم الخدمات الحكومية، معالجة الاستعلامات والشكاوى، 
            والتواصل مع المواطنين بخصوص طلباتهم وتحسين جودة الخدمات المقدمة.
          </p>
        </div>
      </section>

      <section class="mb-8">
        <h2 class="text-2xl font-bold bg-gradient-to-r from-gray-800 to-gray-900 dark:from-white dark:to-gray-200 bg-clip-text text-transparent mb-4">
          3. حماية البيانات
        </h2>
        <div class="bg-red-50 dark:bg-red-900/30 p-5 rounded-lg border border-red-200 dark:border-red-700">
          <p class="text-red-800 dark:text-red-200">
            نطبق أعلى معايير الأمان لحماية بياناتكم، بما في ذلك التشفير، المصادقة الآمنة، 
            ومراقبة الوصول المستمرة لضمان سرية وأمان المعلومات.
          </p>
        </div>
      </section>

      <section class="mb-8">
        <h2 class="text-2xl font-bold bg-gradient-to-r from-gray-800 to-gray-900 dark:from-white dark:to-gray-200 bg-clip-text text-transparent mb-4">
          4. حقوق المواطنين
        </h2>
        <div class="bg-purple-50 dark:bg-purple-900/30 p-5 rounded-lg border border-purple-200 dark:border-purple-700">
          <ul class="list-disc pr-6 space-y-2 text-purple-800 dark:text-purple-200">
            <li>الحق في الوصول إلى بياناتكم الشخصية</li>
            <li>الحق في تصحيح أو تحديث المعلومات</li>
            <li>الحق في حذف البيانات غير الضرورية</li>
            <li>الحق في تقييد معالجة البيانات</li>
            <li>الحق في نقل البيانات</li>
          </ul>
        </div>
      </section>
    `,E=()=>w(null,null,function*(){var t;if(l){j(!0);try{localStorage.setItem("privacyHtml",d);const i=new Date;localStorage.setItem("privacyLastUpdated",i.toISOString()),a(i),h(!1);const N=JSON.parse(localStorage.getItem("privacyChangeLog")||"[]");N.push({timestamp:i.toISOString(),editor:(t=s==null?void 0:s.currentEmployee)==null?void 0:t.username,contentLength:d.length,action:"تحديث سياسة الخصوصية"}),localStorage.setItem("privacyChangeLog",JSON.stringify(N.slice(-50))),alert("تم حفظ سياسة الخصوصية بنجاح!")}catch(i){console.error("خطأ في حفظ سياسة الخصوصية:",i),alert("حدث خطأ في حفظ التغييرات")}finally{j(!1)}}}),I=()=>{confirm("هل أنت متأكد من التراجع عن جميع التغييرات غير المحفوظة؟")&&(f(),h(!1))},T=()=>{window.open("/#/privacy","_blank")},H=t=>{r(t),h(!0)};return!(s!=null&&s.isEmployeeLoggedIn)||!s.currentEmployee?e.jsx("div",{className:"min-h-screen flex items-center justify-center",children:e.jsx(o,{children:e.jsxs("div",{className:"text-center p-8",children:[e.jsx("div",{className:"w-16 h-16 bg-gray-300 mx-auto mb-4 rounded-full flex items-center justify-center",children:"🔒"}),e.jsx("h2",{className:"text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2",children:"مطلوب تسجيل الدخول"}),e.jsx("p",{className:"text-gray-600 dark:text-gray-400 mb-4",children:"يجب تسجيل الدخول للوصول إلى محرر سياسة الخصوصية"}),e.jsx(x,{onClick:()=>window.location.hash="#/login",children:"تسجيل الدخول"})]})})}):L?e.jsxs("div",{className:"max-w-7xl mx-auto space-y-6",children:[e.jsx(o,{children:e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsxs(x,{onClick:()=>window.location.hash="#/dashboard",variant:"secondary",className:"flex items-center gap-2",children:[e.jsx(P,{}),"العودة"]}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-2xl font-bold text-gray-900 dark:text-white",children:"محرر سياسة الخصوصية وحماية البيانات"}),e.jsx("p",{className:"text-gray-600 dark:text-gray-300 text-sm",children:"تحرير وإدارة سياسة الخصوصية للموقع الإلكتروني"})]})]}),e.jsxs("div",{className:"flex items-center gap-3",children:[n&&e.jsxs("span",{className:"text-xs text-gray-500",children:["آخر حفظ: ",S(n)]}),e.jsxs("div",{className:"flex bg-gray-100 dark:bg-gray-800 rounded-lg p-1",children:[e.jsxs("button",{onClick:()=>m("edit"),className:`px-3 py-1 text-sm rounded-md transition-colors ${g==="edit"?"bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm":"text-gray-600 dark:text-gray-400"}`,children:[e.jsx(A,{className:"inline mr-1"}),"تحرير"]}),e.jsxs("button",{onClick:()=>m("preview"),className:`px-3 py-1 text-sm rounded-md transition-colors ${g==="preview"?"bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm":"text-gray-600 dark:text-gray-400"}`,children:[e.jsx(C,{className:"inline mr-1"}),"معاينة"]})]})]})]})}),e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-3 gap-6",children:[e.jsx("div",{className:"lg:col-span-2",children:e.jsx(o,{children:e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsx("h3",{className:"text-lg font-semibold text-gray-900 dark:text-white",children:"محتوى سياسة الخصوصية"}),e.jsxs("div",{className:"flex items-center gap-2",children:[l&&e.jsx("span",{className:"text-xs bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-200 px-2 py-1 rounded",children:"غير محفوظ"}),e.jsxs("span",{className:"text-xs text-gray-500",children:[d.length," حرف"]})]})]}),g==="edit"?e.jsx(F,{label:"",id:"privacy-content",value:d,onChange:t=>H(t.target.value),rows:20,className:"font-mono text-sm",placeholder:"أدخل محتوى سياسة الخصوصية بتنسيق HTML..."}):e.jsx("div",{className:"min-h-[400px] p-4 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-800",dangerouslySetInnerHTML:{__html:d}}),e.jsxs("div",{className:"flex items-center gap-3 pt-4 border-t border-gray-200 dark:border-gray-700",children:[e.jsxs(x,{onClick:E,disabled:!l||u,className:"flex items-center gap-2",children:[e.jsx(D,{}),u?"جاري الحفظ...":"حفظ التغييرات"]}),e.jsxs(x,{onClick:I,variant:"secondary",disabled:!l,className:"flex items-center gap-2",children:[e.jsx(O,{}),"إلغاء التغييرات"]}),e.jsxs(x,{onClick:T,variant:"secondary",className:"flex items-center gap-2",children:[e.jsx(C,{}),"معاينة الصفحة"]})]})]})})}),e.jsxs("div",{className:"space-y-6",children:[e.jsxs(o,{children:[e.jsx("h4",{className:"font-semibold text-gray-900 dark:text-white mb-3",children:"نصائح التحرير"}),e.jsxs("div",{className:"space-y-3 text-sm text-gray-600 dark:text-gray-400",children:[e.jsxs("div",{className:"bg-blue-50 dark:bg-blue-900/30 p-3 rounded",children:[e.jsx("strong",{className:"text-blue-700 dark:text-blue-300",children:"HTML:"}),e.jsx("p",{children:"يمكنك استخدام HTML لتنسيق المحتوى"})]}),e.jsxs("div",{className:"bg-green-50 dark:bg-green-900/30 p-3 rounded",children:[e.jsx("strong",{className:"text-green-700 dark:text-green-300",children:"CSS Classes:"}),e.jsx("p",{children:"استخدم فئات Tailwind للتصميم"})]}),e.jsxs("div",{className:"bg-purple-50 dark:bg-purple-900/30 p-3 rounded",children:[e.jsx("strong",{className:"text-purple-700 dark:text-purple-300",children:"RTL:"}),e.jsx("p",{children:"تأكد من دعم النص العربي من اليمين لليسار"})]})]})]}),e.jsxs(o,{children:[e.jsx("h4",{className:"font-semibold text-gray-900 dark:text-white mb-3",children:"علامات HTML مفيدة"}),e.jsxs("div",{className:"space-y-2 text-xs text-gray-600 dark:text-gray-400",children:[e.jsx("div",{className:"bg-gray-50 dark:bg-gray-800 p-2 rounded font-mono",children:"<h2>عنوان رئيسي</h2>"}),e.jsx("div",{className:"bg-gray-50 dark:bg-gray-800 p-2 rounded font-mono",children:"<p>فقرة نص</p>"}),e.jsx("div",{className:"bg-gray-50 dark:bg-gray-800 p-2 rounded font-mono",children:"<ul><li>عنصر قائمة</li></ul>"}),e.jsx("div",{className:"bg-gray-50 dark:bg-gray-800 p-2 rounded font-mono",children:"<strong>نص عريض</strong>"}),e.jsx("div",{className:"bg-gray-50 dark:bg-gray-800 p-2 rounded font-mono",children:'<div class="bg-blue-50 p-4">صندوق ملون</div>'})]})]}),e.jsxs(o,{children:[e.jsx("h4",{className:"font-semibold text-gray-900 dark:text-white mb-3",children:"إجراءات سريعة"}),e.jsxs("div",{className:"space-y-2",children:[e.jsx(x,{onClick:()=>r(p()),variant:"secondary",className:"w-full text-sm",children:"إعادة تعيين للمحتوى الافتراضي"}),e.jsx(x,{onClick:()=>{r(d+`
                    <section class="mb-8">
                      <h2 class="text-2xl font-bold mb-4">عنوان القسم</h2>
                      <p class="text-gray-700 dark:text-gray-300">محتوى القسم...</p>
                    </section>
                  `),h(!0)},variant:"secondary",className:"w-full text-sm",children:"إضافة قسم جديد"})]})]}),e.jsxs(o,{children:[e.jsx("h4",{className:"font-semibold text-gray-900 dark:text-white mb-3",children:"معلومات النسخة"}),e.jsxs("div",{className:"space-y-2 text-sm text-gray-600 dark:text-gray-400",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"المحرر:"})," ",(k=s==null?void 0:s.currentEmployee)==null?void 0:k.username]}),e.jsxs("p",{children:[e.jsx("strong",{children:"آخر تحديث:"})," ",n?S(n):"غير محدد"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"حالة المحتوى:"})," ",l?"🔄 معدل":"✅ محفوظ"]})]})]})]})]})]}):e.jsx("div",{className:"min-h-screen flex items-center justify-center",children:e.jsx(o,{children:e.jsxs("div",{className:"text-center p-8",children:[e.jsx("div",{className:"w-16 h-16 bg-red-100 mx-auto mb-4 rounded-full flex items-center justify-center",children:"⚠️"}),e.jsx("h2",{className:"text-xl font-semibold text-red-800 dark:text-red-200 mb-2",children:"غير مصرح"}),e.jsx("p",{className:"text-red-600 dark:text-red-400 mb-4",children:"هذه الصفحة مخصصة لمديري النظام فقط"}),e.jsx(x,{onClick:()=>window.location.hash="#/dashboard",children:"العودة للوحة التحكم"})]})})})};export{$ as default};
