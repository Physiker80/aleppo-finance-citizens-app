function r(e){return new Worker("/assets/pdf.worker.min-DqO1ZFDz.js",{name:e==null?void 0:e.name})}export{r as default};
