const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/jspdf.es.min-BsawNrML.js","assets/index-BkIQX736.js","assets/index-CXrkSpBK.css"])))=>i.map(i=>d[i]);
var be=Object.defineProperty,ye=Object.defineProperties;var fe=Object.getOwnPropertyDescriptors;var G=Object.getOwnPropertySymbols;var je=Object.prototype.hasOwnProperty,ve=Object.prototype.propertyIsEnumerable;var K=(t,a,s)=>a in t?be(t,a,{enumerable:!0,configurable:!0,writable:!0,value:s}):t[a]=s,N=(t,a)=>{for(var s in a||(a={}))je.call(a,s)&&K(t,s,a[s]);if(G)for(var s of G(a))ve.call(a,s)&&K(t,s,a[s]);return t},$=(t,a)=>ye(t,fe(a));var A=(t,a,s)=>new Promise((i,r)=>{var o=d=>{try{l(s.next(d))}catch(n){r(n)}},m=d=>{try{l(s.throw(d))}catch(n){r(n)}},l=d=>d.done?i(d.value):Promise.resolve(d.value).then(o,m);l((s=s.apply(t,a)).next())});import{r as j,j as e,_ as ke,A as we,V as Ne,W as Se,X as Ce,C as $e,Y as Ee,Z as Fe,$ as De,B as O,a0 as Ae,a1 as Ie}from"./index-BkIQX736.js";import{H as le,E as M,I as Re,C as Oe,u as _e,J as oe,K as Le,j as Te,k as Me,L as J,M as ze,N as Pe,O as Ue,P as We,m as Be,Q as Je}from"./index-CjB4vxPV.js";const qe=()=>navigator.onLine,Ve=t=>{const a=()=>t(!0),s=()=>t(!1);return window.addEventListener("online",a),window.addEventListener("offline",s),()=>{window.removeEventListener("online",a),window.removeEventListener("offline",s)}},Ye="offlineSyncQueue",X=()=>{try{const t=localStorage.getItem(Ye);return t?JSON.parse(t):[]}catch(t){return console.error("Error reading sync queue:",t),[]}},ce=t=>t?new Date(t).toLocaleDateString("ar-SY",{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit"}):"",Qe=(t,a,s)=>{if(t.length===0){alert("لا توجد بيانات للتصدير");return}const i="\uFEFF",r=s.map(l=>`"${l.label}"`).join(","),o=t.map(l=>s.map(d=>{let n=l[d.key];return n==null&&(n=""),n instanceof Date&&(n=ce(n)),typeof n=="object"&&(n=JSON.stringify(n)),`"${String(n).replace(/"/g,'""')}"`}).join(",")).join(`
`),m=i+r+`
`+o;Q(m,`${a}.csv`,"text/csv;charset=utf-8")},He=(t,a)=>{if(t.length===0){alert("لا توجد بيانات للتصدير");return}const s=JSON.stringify(t,null,2);Q(s,`${a}.json`,"application/json")},Ge=(t,a,s,i="البيانات")=>{if(t.length===0){alert("لا توجد بيانات للتصدير");return}const r='<?xml version="1.0" encoding="UTF-8"?><?mso-application progid="Excel.Sheet"?>',o='<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">',m="</Workbook>",l=`
    <Styles>
      <Style ss:ID="header">
        <Font ss:Bold="1" ss:Size="12"/>
        <Interior ss:Color="#4472C4" ss:Pattern="Solid"/>
        <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
      </Style>
      <Style ss:ID="data">
        <Alignment ss:Horizontal="Right" ss:Vertical="Center"/>
      </Style>
    </Styles>
  `;let d=`<Worksheet ss:Name="${i}"><Table>`;d+='<Row ss:StyleID="header">',s.forEach(y=>{d+=`<Cell><Data ss:Type="String">${y.label}</Data></Cell>`}),d+="</Row>",t.forEach(y=>{d+='<Row ss:StyleID="data">',s.forEach(c=>{let g=y[c.key];g==null&&(g=""),g instanceof Date&&(g=ce(g)),typeof g=="object"&&(g=JSON.stringify(g)),d+=`<Cell><Data ss:Type="${typeof g=="number"?"Number":"String"}">${String(g)}</Data></Cell>`}),d+="</Row>"}),d+="</Table></Worksheet>";const n=r+o+l+d+m;Q(n,`${a}.xls`,"application/vnd.ms-excel")},Q=(t,a,s)=>{const i=new Blob([t],{type:s}),r=URL.createObjectURL(i),o=document.createElement("a");o.href=r,o.download=a,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(r)},Z=({data:t,size:a=200,showLabels:s=!0,showLegend:i=!0,title:r})=>{const o=j.useMemo(()=>t.reduce((c,g)=>c+g.value,0),[t]),m=j.useMemo(()=>{let c=0;return t.map(g=>{const b=o>0?g.value/o*100:0,v=b/100*360,h=c;return c+=v,$(N({},g),{percentage:b,startAngle:h,endAngle:c})})},[t,o]),l=(c,g)=>{const b=(c-90)*(Math.PI/180);return{x:g*Math.cos(b),y:g*Math.sin(b)}},d=(c,g,b)=>{const v=l(c,b),h=l(g,b),f=g-c>180?1:0;return`M 0 0 L ${v.x} ${v.y} A ${b} ${b} 0 ${f} 1 ${h.x} ${h.y} Z`},n=a/2-10,y=a/2;return e.jsxs("div",{className:"flex flex-col items-center gap-4",children:[r&&e.jsx("h3",{className:"text-lg font-semibold text-gray-800 dark:text-gray-200",children:r}),e.jsxs("div",{className:"flex items-center gap-6 flex-wrap justify-center",children:[e.jsx("svg",{width:a,height:a,className:"transform -rotate-90",children:e.jsx("g",{transform:`translate(${y}, ${y})`,children:m.map((c,g)=>e.jsxs("g",{children:[e.jsx("path",{d:d(c.startAngle,c.endAngle,n),fill:c.color,className:"transition-all duration-300 hover:opacity-80 cursor-pointer",stroke:"white",strokeWidth:"2",children:e.jsxs("title",{children:[c.label,": ",c.value," (",c.percentage.toFixed(1),"%)"]})}),s&&c.percentage>5&&e.jsxs("text",{x:l((c.startAngle+c.endAngle)/2,n*.65).x,y:l((c.startAngle+c.endAngle)/2,n*.65).y,textAnchor:"middle",dominantBaseline:"middle",fill:"white",fontSize:"12",fontWeight:"bold",className:"rotate-90",style:{transform:"rotate(90deg)",transformOrigin:"center"},children:[c.percentage.toFixed(0),"%"]})]},g))})}),i&&e.jsx("div",{className:"flex flex-col gap-2",children:m.map((c,g)=>e.jsxs("div",{className:"flex items-center gap-2 text-sm",children:[e.jsx("span",{className:"w-4 h-4 rounded",style:{backgroundColor:c.color}}),e.jsx("span",{className:"text-gray-700 dark:text-gray-300",children:c.label}),e.jsxs("span",{className:"font-semibold text-gray-900 dark:text-gray-100",children:["(",c.value,")"]})]},g))})]})]})},ee=({data:t,height:a=200,showValues:s=!0,title:i,horizontal:r=!1,maxValue:o})=>{const m=o||Math.max(...t.map(d=>d.value),1),l=["#3b82f6","#10b981","#f59e0b","#ef4444","#8b5cf6","#06b6d4"];return r?e.jsxs("div",{className:"w-full",children:[i&&e.jsx("h3",{className:"text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4",children:i}),e.jsx("div",{className:"space-y-3",children:t.map((d,n)=>e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"w-24 text-sm text-gray-600 dark:text-gray-400 text-left truncate",children:d.label}),e.jsx("div",{className:"flex-1 h-8 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden",children:e.jsx("div",{className:"h-full rounded-full transition-all duration-500 flex items-center justify-end px-2",style:{width:`${d.value/m*100}%`,backgroundColor:d.color||l[n%l.length]},children:s&&e.jsx("span",{className:"text-white text-xs font-bold",children:d.value})})})]},n))})]}):e.jsxs("div",{className:"w-full",children:[i&&e.jsx("h3",{className:"text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4 text-center",children:i}),e.jsx("div",{className:"flex items-end justify-center gap-2",style:{height:a},children:t.map((d,n)=>e.jsxs("div",{className:"flex flex-col items-center gap-1",children:[s&&e.jsx("span",{className:"text-xs font-bold text-gray-700 dark:text-gray-300",children:d.value}),e.jsx("div",{className:"w-12 rounded-t-lg transition-all duration-500 hover:opacity-80",style:{height:`${d.value/m*(a-40)}px`,backgroundColor:d.color||l[n%l.length],minHeight:"4px"},title:`${d.label}: ${d.value}`}),e.jsx("span",{className:"text-xs text-gray-600 dark:text-gray-400 text-center w-16 truncate",children:d.label})]},n))})]})},Ke=({data:t,width:a=400,height:s=200,color:i="#3b82f6",title:r,showDots:o=!0,showArea:m=!0})=>{var f;const d=a-80,n=s-80,y=Math.max(...t.map(p=>p.value),1),c=Math.min(...t.map(p=>p.value),0),g=y-c||1,b=j.useMemo(()=>t.map((p,u)=>N({x:40+u/(t.length-1||1)*d,y:s-40-(p.value-c)/g*n},p)),[t,d,n,c,g,s,40]),v=b.map((p,u)=>`${u===0?"M":"L"} ${p.x} ${p.y}`).join(" "),h=`${v} L ${((f=b[b.length-1])==null?void 0:f.x)||0} ${s-40} L 40 ${s-40} Z`;return e.jsxs("div",{children:[r&&e.jsx("h3",{className:"text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4 text-center",children:r}),e.jsxs("svg",{width:a,height:s,className:"overflow-visible",children:[[0,.25,.5,.75,1].map((p,u)=>e.jsxs("g",{children:[e.jsx("line",{x1:40,y1:s-40-p*n,x2:a-40,y2:s-40-p*n,stroke:"#e5e7eb",strokeDasharray:"4"}),e.jsx("text",{x:35,y:s-40-p*n,textAnchor:"end",dominantBaseline:"middle",fill:"#9ca3af",fontSize:"10",children:Math.round(c+p*g)})]},u)),m&&e.jsx("path",{d:h,fill:i,fillOpacity:"0.1"}),e.jsx("path",{d:v,fill:"none",stroke:i,strokeWidth:"2"}),o&&b.map((p,u)=>e.jsx("g",{children:e.jsx("circle",{cx:p.x,cy:p.y,r:"4",fill:i,className:"cursor-pointer hover:r-6 transition-all",children:e.jsxs("title",{children:[p.label,": ",p.value]})})},u)),b.map((p,u)=>e.jsx("text",{x:p.x,y:s-40+15,textAnchor:"middle",fill:"#6b7280",fontSize:"10",children:p.label},u))]})]})},Xe=({data:t,size:a=180,thickness:s=30,centerLabel:i,centerValue:r})=>{const o=j.useMemo(()=>t.reduce((n,y)=>n+y.value,0),[t]),m=(a-s)/2,l=2*Math.PI*m;let d=0;return e.jsxs("div",{className:"relative",style:{width:a,height:a},children:[e.jsx("svg",{width:a,height:a,className:"transform -rotate-90",children:t.map((n,y)=>{const c=o>0?n.value/o:0,g=`${c*l} ${l}`,b=-d;return d+=c*l,e.jsx("circle",{cx:a/2,cy:a/2,r:m,fill:"none",stroke:n.color,strokeWidth:s,strokeDasharray:g,strokeDashoffset:b,className:"transition-all duration-500",children:e.jsxs("title",{children:[n.label,": ",n.value," (",(c*100).toFixed(1),"%)"]})},y)})}),(i||r)&&e.jsxs("div",{className:"absolute inset-0 flex flex-col items-center justify-center",children:[r&&e.jsx("span",{className:"text-2xl font-bold text-gray-800 dark:text-gray-100",children:r}),i&&e.jsx("span",{className:"text-sm text-gray-500 dark:text-gray-400",children:i})]})]})},de={query:"",status:[],department:[],dateFrom:"",dateTo:"",source:[],priority:[],hasAttachments:null,hasResponse:null},Ze=({filters:t,onFiltersChange:a,departments:s,showStatusFilter:i=!0,showSourceFilter:r=!0,showDateFilter:o=!0,showAttachmentFilter:m=!0,showResponseFilter:l=!0,placeholder:d="ابحث...",className:n=""})=>{const[y,c]=j.useState(!1),[g,b]=j.useState(t.query);j.useEffect(()=>{const x=setTimeout(()=>{g!==t.query&&a($(N({},t),{query:g}))},300);return()=>clearTimeout(x)},[g]);const v=[{value:"New",label:"جديد",color:"bg-blue-500"},{value:"InProgress",label:"قيد المعالجة",color:"bg-yellow-500"},{value:"Answered",label:"تم الرد",color:"bg-green-500"},{value:"Closed",label:"مغلق",color:"bg-gray-500"}],h=[{value:"مواطن",label:"مواطن"},{value:"موظف",label:"موظف"}],f=j.useMemo(()=>{let x=0;return t.status.length>0&&x++,t.department.length>0&&x++,(t.dateFrom||t.dateTo)&&x++,t.source.length>0&&x++,t.hasAttachments!==null&&x++,t.hasResponse!==null&&x++,x},[t]),p=()=>{a(de),b("")},u=(x,k)=>{const w=t[x],C=w.includes(k)?w.filter(F=>F!==k):[...w,k];a($(N({},t),{[x]:C}))};return e.jsxs("div",{className:`bg-white dark:bg-gray-800 rounded-2xl shadow-lg border border-gray-200 dark:border-gray-700 ${n}`,children:[e.jsxs("div",{className:"p-4 flex items-center gap-3",children:[e.jsxs("div",{className:"relative flex-1",children:[e.jsx("input",{type:"text",value:g,onChange:x=>b(x.target.value),placeholder:d,className:"w-full pl-10 pr-4 py-3 bg-gray-100 dark:bg-gray-700 rounded-xl border-0 focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-gray-100"}),e.jsx("svg",{className:"absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"})}),g&&e.jsx("button",{onClick:()=>{b(""),a($(N({},t),{query:""}))},className:"absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600",children:"✕"})]}),e.jsxs("button",{onClick:()=>c(!y),className:`px-4 py-3 rounded-xl flex items-center gap-2 transition-colors ${y||f>0?"bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300":"bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"}`,children:[e.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"})}),e.jsx("span",{children:"فلاتر"}),f>0&&e.jsx("span",{className:"bg-blue-600 text-white text-xs px-2 py-0.5 rounded-full",children:f})]}),f>0&&e.jsx("button",{onClick:p,className:"px-4 py-3 bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 rounded-xl hover:bg-red-200 dark:hover:bg-red-800 transition-colors",children:"مسح الكل"})]}),y&&e.jsxs("div",{className:"p-4 border-t border-gray-200 dark:border-gray-700 space-y-4",children:[i&&e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2",children:"الحالة"}),e.jsx("div",{className:"flex flex-wrap gap-2",children:v.map(x=>e.jsxs("button",{onClick:()=>u("status",x.value),className:`px-3 py-1.5 rounded-full text-sm flex items-center gap-2 transition-colors ${t.status.includes(x.value)?"bg-blue-600 text-white":"bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"}`,children:[e.jsx("span",{className:`w-2 h-2 rounded-full ${x.color}`}),x.label]},x.value))})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2",children:"القسم"}),e.jsx("div",{className:"flex flex-wrap gap-2",children:s.map(x=>e.jsx("button",{onClick:()=>u("department",x),className:`px-3 py-1.5 rounded-full text-sm transition-colors ${t.department.includes(x)?"bg-green-600 text-white":"bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"}`,children:x},x))})]}),r&&e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2",children:"المصدر"}),e.jsx("div",{className:"flex flex-wrap gap-2",children:h.map(x=>e.jsx("button",{onClick:()=>u("source",x.value),className:`px-3 py-1.5 rounded-full text-sm transition-colors ${t.source.includes(x.value)?"bg-purple-600 text-white":"bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"}`,children:x.label},x.value))})]}),o&&e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2",children:"من تاريخ"}),e.jsx("input",{type:"date",value:t.dateFrom,onChange:x=>a($(N({},t),{dateFrom:x.target.value})),className:"w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 rounded-lg border-0 focus:ring-2 focus:ring-blue-500"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2",children:"إلى تاريخ"}),e.jsx("input",{type:"date",value:t.dateTo,onChange:x=>a($(N({},t),{dateTo:x.target.value})),className:"w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 rounded-lg border-0 focus:ring-2 focus:ring-blue-500"})]})]}),e.jsxs("div",{className:"flex flex-wrap gap-4",children:[m&&e.jsxs("label",{className:"flex items-center gap-2 cursor-pointer",children:[e.jsx("input",{type:"checkbox",checked:t.hasAttachments===!0,onChange:x=>a($(N({},t),{hasAttachments:x.target.checked?!0:null})),className:"w-4 h-4 rounded text-blue-600 focus:ring-blue-500"}),e.jsx("span",{className:"text-sm text-gray-700 dark:text-gray-300",children:"يحتوي مرفقات"})]}),l&&e.jsxs("label",{className:"flex items-center gap-2 cursor-pointer",children:[e.jsx("input",{type:"checkbox",checked:t.hasResponse===!0,onChange:x=>a($(N({},t),{hasResponse:x.target.checked?!0:null})),className:"w-4 h-4 rounded text-blue-600 focus:ring-blue-500"}),e.jsx("span",{className:"text-sm text-gray-700 dark:text-gray-300",children:"تم الرد عليه"})]})]})]})]})},ge=`
@media print {
  /* إعدادات الصفحة */
  @page {
    size: A4;
    margin: 2cm;
    direction: rtl;
  }

  /* إخفاء العناصر غير المطلوبة */
  header,
  footer,
  nav,
  aside,
  .no-print,
  .sidebar,
  .navigation,
  .fab,
  .modal-overlay,
  button:not(.print-visible),
  input[type="button"],
  input[type="submit"],
  .scroll-progress,
  .cookie-banner,
  .toast,
  .notification-badge,
  .emoji-rating,
  .gamification-widget {
    display: none !important;
  }

  /* إظهار المحتوى المخفي للطباعة */
  .print-only {
    display: block !important;
  }

  /* إعدادات الخط */
  body {
    font-family: 'Cairo', 'Segoe UI', Arial, sans-serif !important;
    font-size: 12pt !important;
    line-height: 1.6 !important;
    color: #000 !important;
    background: #fff !important;
    direction: rtl !important;
  }

  /* العناوين */
  h1 {
    font-size: 18pt !important;
    font-weight: bold !important;
    margin-bottom: 12pt !important;
    color: #000 !important;
    border-bottom: 2px solid #000 !important;
    padding-bottom: 6pt !important;
  }

  h2 {
    font-size: 16pt !important;
    font-weight: bold !important;
    margin-bottom: 10pt !important;
    margin-top: 14pt !important;
    color: #000 !important;
  }

  h3 {
    font-size: 14pt !important;
    font-weight: bold !important;
    margin-bottom: 8pt !important;
    color: #333 !important;
  }

  /* الروابط */
  a {
    color: #000 !important;
    text-decoration: underline !important;
  }

  a[href]:after {
    content: " (" attr(href) ")";
    font-size: 10pt;
    color: #666;
  }

  a[href^="#"]:after,
  a[href^="javascript"]:after {
    content: "";
  }

  /* الجداول */
  table {
    width: 100% !important;
    border-collapse: collapse !important;
    margin: 12pt 0 !important;
    page-break-inside: avoid !important;
  }

  th, td {
    border: 1px solid #333 !important;
    padding: 8pt !important;
    text-align: right !important;
  }

  th {
    background-color: #f0f0f0 !important;
    font-weight: bold !important;
  }

  tr:nth-child(even) {
    background-color: #f9f9f9 !important;
  }

  /* البطاقات */
  .card,
  .ticket-card {
    border: 1px solid #333 !important;
    padding: 12pt !important;
    margin: 8pt 0 !important;
    page-break-inside: avoid !important;
    background: #fff !important;
    box-shadow: none !important;
    border-radius: 0 !important;
  }

  /* الصور */
  img {
    max-width: 100% !important;
    height: auto !important;
    page-break-inside: avoid !important;
  }

  /* منع كسر الصفحة داخل العناصر */
  .page-break-avoid {
    page-break-inside: avoid !important;
  }

  /* إجبار كسر الصفحة */
  .page-break-before {
    page-break-before: always !important;
  }

  .page-break-after {
    page-break-after: always !important;
  }

  /* الترويسة المطبوعة */
  .print-header {
    display: block !important;
    text-align: center !important;
    margin-bottom: 20pt !important;
    border-bottom: 2px solid #000 !important;
    padding-bottom: 10pt !important;
  }

  .print-header img {
    max-height: 60pt !important;
    margin-bottom: 8pt !important;
  }

  .print-header h1 {
    border: none !important;
    margin-bottom: 4pt !important;
  }

  /* التذييل المطبوع */
  .print-footer {
    display: block !important;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    text-align: center;
    font-size: 10pt;
    border-top: 1px solid #333;
    padding-top: 8pt;
  }

  /* التوقيعات */
  .signature-area {
    display: flex !important;
    justify-content: space-between !important;
    margin-top: 40pt !important;
    page-break-inside: avoid !important;
  }

  .signature-box {
    width: 200pt !important;
    text-align: center !important;
    border-top: 1px solid #000 !important;
    padding-top: 8pt !important;
  }

  /* الحالات */
  .status-badge {
    padding: 4pt 8pt !important;
    border: 1px solid #000 !important;
    background: transparent !important;
    color: #000 !important;
  }

  /* QR Code */
  .qr-code {
    display: block !important;
    width: 80pt !important;
    height: 80pt !important;
    margin: 8pt auto !important;
  }

  /* أرقام الصفحات */
  .page-number:after {
    content: counter(page) " من " counter(pages);
    counter-increment: page;
  }

  /* محتوى منسق مسبقاً */
  pre, code {
    font-family: monospace !important;
    font-size: 10pt !important;
    background: #f5f5f5 !important;
    border: 1px solid #ddd !important;
    padding: 8pt !important;
    white-space: pre-wrap !important;
    word-wrap: break-word !important;
  }

  /* القوائم */
  ul, ol {
    margin: 8pt 0 !important;
    padding-right: 20pt !important;
  }

  li {
    margin-bottom: 4pt !important;
  }
}
`,et=t=>{const a=window.open("","_blank");if(!a){alert("يرجى السماح بالنوافذ المنبثقة للطباعة");return}const s={New:"جديد",InProgress:"قيد المعالجة",Answered:"تم الرد",Closed:"مغلق"},i=r=>new Date(r).toLocaleDateString("ar-SY",{year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit"});a.document.write(`
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
      <meta charset="UTF-8">
      <title>تذكرة رقم ${t.id}</title>
      <style>
        ${ge}
        body {
          font-family: 'Cairo', Arial, sans-serif;
          padding: 40px;
          direction: rtl;
        }
        .print-container {
          max-width: 800px;
          margin: 0 auto;
        }
        .header {
          text-align: center;
          border-bottom: 3px double #000;
          padding-bottom: 20px;
          margin-bottom: 30px;
        }
        .header h1 {
          margin: 0;
          font-size: 24px;
        }
        .header h2 {
          margin: 10px 0;
          font-size: 18px;
          color: #333;
        }
        .ticket-info {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 15px;
          margin-bottom: 30px;
        }
        .info-item {
          border: 1px solid #ddd;
          padding: 12px;
          border-radius: 4px;
        }
        .info-label {
          font-weight: bold;
          color: #555;
          margin-bottom: 5px;
        }
        .info-value {
          font-size: 16px;
        }
        .message-section {
          margin-bottom: 30px;
        }
        .message-section h3 {
          border-bottom: 1px solid #000;
          padding-bottom: 8px;
          margin-bottom: 15px;
        }
        .message-content {
          background: #f9f9f9;
          padding: 20px;
          border: 1px solid #ddd;
          border-radius: 4px;
          white-space: pre-wrap;
        }
        .footer {
          margin-top: 50px;
          display: flex;
          justify-content: space-between;
        }
        .signature-box {
          text-align: center;
          width: 200px;
        }
        .signature-line {
          border-top: 1px solid #000;
          margin-top: 60px;
          padding-top: 8px;
        }
        .status-badge {
          display: inline-block;
          padding: 5px 15px;
          border: 2px solid #000;
          font-weight: bold;
        }
      </style>
    </head>
    <body>
      <div class="print-container">
        <div class="header">
          <h1>الجمهورية العربية السورية</h1>
          <h2>مديرية مالية حلب</h2>
          <h2>نظام الاستعلامات والشكاوى</h2>
        </div>
        
        <div class="ticket-info">
          <div class="info-item">
            <div class="info-label">رقم التذكرة</div>
            <div class="info-value">${t.id}</div>
          </div>
          <div class="info-item">
            <div class="info-label">الحالة</div>
            <div class="info-value">
              <span class="status-badge">${s[t.status]}</span>
            </div>
          </div>
          <div class="info-item">
            <div class="info-label">الاسم الكامل</div>
            <div class="info-value">${t.fullName}</div>
          </div>
          <div class="info-item">
            <div class="info-label">الرقم الوطني</div>
            <div class="info-value">${t.nationalId}</div>
          </div>
          <div class="info-item">
            <div class="info-label">القسم</div>
            <div class="info-value">${t.department}</div>
          </div>
          <div class="info-item">
            <div class="info-label">نوع الطلب</div>
            <div class="info-value">${t.requestType}</div>
          </div>
          <div class="info-item" style="grid-column: span 2;">
            <div class="info-label">تاريخ الإنشاء</div>
            <div class="info-value">${i(t.createdAt)}</div>
          </div>
        </div>
        
        <div class="message-section">
          <h3>نص الطلب</h3>
          <div class="message-content">${t.message}</div>
        </div>
        
        ${t.response?`
        <div class="message-section">
          <h3>الرد</h3>
          <div class="message-content">${t.response}</div>
        </div>
        `:""}
        
        <div class="footer">
          <div class="signature-box">
            <div class="signature-line">توقيع الموظف المختص</div>
          </div>
          <div class="signature-box">
            <div class="signature-line">ختم المديرية</div>
          </div>
        </div>
      </div>
    </body>
    </html>
  `),a.document.close(),a.focus(),setTimeout(()=>{a.print(),a.close()},500)},me=()=>{const t="print-styles";if(document.getElementById(t))return;const a=document.createElement("style");a.id=t,a.textContent=ge,document.head.appendChild(a)};typeof window!="undefined"&&me();const tt={maxWidth:1920,maxHeight:1080,quality:.8,mimeType:"image/jpeg",maxSizeKB:500},at=(s,...i)=>A(null,[s,...i],function*(t,a={}){const r=N(N({},tt),a),o=t.size;if(!t.type.startsWith("image/"))throw new Error("الملف ليس صورة");return o<=r.maxSizeKB*1024?{file:t,originalSize:o,compressedSize:o,compressionRatio:1,width:0,height:0}:new Promise((m,l)=>{const d=new Image,n=document.createElement("canvas"),y=n.getContext("2d");d.onload=()=>{try{let{width:c,height:g}=d;c>r.maxWidth&&(g=g*r.maxWidth/c,c=r.maxWidth),g>r.maxHeight&&(c=c*r.maxHeight/g,g=r.maxHeight),n.width=c,n.height=g,y.fillStyle="#FFFFFF",y.fillRect(0,0,c,g),y.drawImage(d,0,0,c,g);let b=r.quality,v=null;const h=()=>{n.toBlob(f=>{if(!f){l(new Error("فشل في ضغط الصورة"));return}if(f.size<=r.maxSizeKB*1024||b<=.1){const p=new File([f],t.name.replace(/\.[^.]+$/,".jpg"),{type:r.mimeType});m({file:p,originalSize:o,compressedSize:f.size,compressionRatio:o/f.size,width:c,height:g})}else b-=.1,h()},r.mimeType,b)};h()}catch(c){l(c)}},d.onerror=()=>l(new Error("فشل في تحميل الصورة")),d.src=URL.createObjectURL(t)})}),st=(i,...r)=>A(null,[i,...r],function*(t,a={},s){const o=[],m=t.length;for(let l=0;l<t.length;l++){const d=t[l];if(d.type.startsWith("image/")){const n=yield at(d,a);o.push(n)}else o.push({file:d,originalSize:d.size,compressedSize:d.size,compressionRatio:1,width:0,height:0});s==null||s((l+1)/m*100,l+1,m)}return o}),W=t=>{if(t===0)return"0 بايت";const a=1024,s=["بايت","كيلوبايت","ميجابايت","جيجابايت"],i=Math.floor(Math.log(t)/Math.log(a));return`${parseFloat((t/Math.pow(a,i)).toFixed(2))} ${s[i]}`},rt=({onCompress:t,maxFiles:a=10,options:s={}})=>{const[i,r]=j.useState([]),[o,m]=j.useState([]),[l,d]=j.useState(!1),[n,y]=j.useState(0),c=j.useRef(null),g=j.useCallback(f=>A(null,null,function*(){const p=Array.from(f.target.files||[]).slice(0,a);r(p),d(!0),y(0);try{const u=yield st(p,s,(x,k,w)=>y(x));m(u),t(u.map(x=>x.file))}catch(u){console.error("Error compressing images:",u)}finally{d(!1)}}),[a,s,t]),b=o.reduce((f,p)=>f+p.originalSize,0),v=o.reduce((f,p)=>f+p.compressedSize,0),h=b-v;return e.jsxs("div",{className:"bg-white dark:bg-gray-800 rounded-xl p-4 border border-gray-200 dark:border-gray-700",children:[e.jsxs("div",{onClick:()=>{var f;return(f=c.current)==null?void 0:f.click()},className:"border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl p-8 text-center cursor-pointer hover:border-blue-500 dark:hover:border-blue-400 transition-colors",children:[e.jsx("input",{ref:c,type:"file",accept:"image/*",multiple:!0,onChange:g,className:"hidden"}),e.jsx("div",{className:"text-4xl mb-3",children:"📷"}),e.jsx("p",{className:"text-gray-600 dark:text-gray-400",children:"اسحب الصور هنا أو اضغط للاختيار"}),e.jsxs("p",{className:"text-sm text-gray-500 dark:text-gray-500 mt-2",children:["الحد الأقصى: ",a," صور"]})]}),l&&e.jsxs("div",{className:"mt-4",children:[e.jsxs("div",{className:"flex items-center justify-between text-sm text-gray-600 dark:text-gray-400 mb-2",children:[e.jsx("span",{children:"جاري الضغط..."}),e.jsxs("span",{children:[Math.round(n),"%"]})]}),e.jsx("div",{className:"w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2",children:e.jsx("div",{className:"bg-blue-600 h-2 rounded-full transition-all duration-300",style:{width:`${n}%`}})})]}),o.length>0&&!l&&e.jsxs("div",{className:"mt-4",children:[e.jsx("div",{className:"bg-green-50 dark:bg-green-900/30 rounded-lg p-4 mb-4",children:e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("span",{className:"text-green-700 dark:text-green-300 font-medium",children:["تم توفير ",W(h)]}),e.jsxs("span",{className:"text-green-600 dark:text-green-400 text-sm",children:[b>0?Math.round(h/b*100):0,"% تقليل"]})]})}),e.jsx("div",{className:"space-y-2 max-h-60 overflow-y-auto",children:o.map((f,p)=>e.jsxs("div",{className:"flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg text-sm",children:[e.jsx("span",{className:"text-gray-700 dark:text-gray-300 truncate max-w-[200px]",children:f.file.name}),e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsxs("span",{className:"text-gray-500 dark:text-gray-400",children:[W(f.originalSize)," → ",W(f.compressedSize)]}),f.compressionRatio>1&&e.jsxs("span",{className:"text-green-600 dark:text-green-400",children:["-",Math.round((1-1/f.compressionRatio)*100),"%"]})]})]},p))})]})]})},te=(t=6)=>{const a="0123456789";let s="";for(let i=0;i<t;i++)s+=a[Math.floor(Math.random()*a.length)];return s},nt=()=>{const t="ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";let a="";for(let s=0;s<32;s++)a+=t[Math.floor(Math.random()*t.length)];return a},it=(t=10)=>{const a=[];for(let s=0;s<t;s++){const i=`${te(4)}-${te(4)}`;a.push(i)}return a},lt=t=>{const a=Math.floor(Date.now()/3e4),s=ot(t+a);return String(s).slice(-6).padStart(6,"0")},ot=t=>{let a=0;for(let s=0;s<t.length;s++){const i=t.charCodeAt(s);a=(a<<5)-a+i,a=a&a}return Math.abs(a)},q="2fa_settings",V="2fa_attempts",ae=5,ct=900*1e3,dt=t=>{try{return JSON.parse(localStorage.getItem(q)||"{}")[t]||null}catch(a){return null}},Y=(t,a)=>{try{const s=JSON.parse(localStorage.getItem(q)||"{}");s[t]=a,localStorage.setItem(q,JSON.stringify(s))}catch(s){console.error("Error saving 2FA settings:",s)}},gt=(t,a="totp")=>{const s=nt(),i=it(),r={enabled:!0,secret:s,backupCodes:i,method:a,lastVerified:new Date().toISOString()};Y(t,r);const o=`otpauth://totp/SyrianFinance:${t}?secret=${s}&issuer=SyrianFinance`;return{secret:s,backupCodes:i,qrCodeUrl:o}},mt=t=>{try{return JSON.parse(localStorage.getItem(V)||"{}")[t]||{count:0}}catch(a){return{count:0}}},T=(t,a,s)=>{try{const i=JSON.parse(localStorage.getItem(V)||"{}");i[t]={count:a,lockedUntil:s},localStorage.setItem(V,JSON.stringify(i))}catch(i){console.error("Error saving attempts:",i)}},xt=(t,a)=>{var d;const s=dt(t);if(!(s!=null&&s.enabled))return{success:!0,message:"التحقق الثنائي غير مفعل"};const i=mt(t);if(i.lockedUntil&&Date.now()<i.lockedUntil)return{success:!1,message:`الحساب مقفل. حاول مرة أخرى بعد ${Math.ceil((i.lockedUntil-Date.now())/6e4)} دقيقة`};const r=a.replace(/\s|-/g,"").toUpperCase(),o=(d=s.backupCodes)==null?void 0:d.findIndex(n=>n.replace(/-/g,"")===r);if(o!==void 0&&o>=0){const n=[...s.backupCodes||[]];return n.splice(o,1),Y(t,$(N({},s),{backupCodes:n})),T(t,0),{success:!0,message:"تم التحقق بالكود الاحتياطي"}}const m=lt(s.secret||"");if(a===m)return Y(t,$(N({},s),{lastVerified:new Date().toISOString()})),T(t,0),{success:!0,message:"تم التحقق بنجاح"};const l=i.count+1;return l>=ae?(T(t,l,Date.now()+ct),{success:!1,message:"تم تجاوز عدد المحاولات. الحساب مقفل لمدة 15 دقيقة",remainingAttempts:0}):(T(t,l),{success:!1,message:"كود التحقق غير صحيح",remainingAttempts:ae-l})},ut=({length:t=6,onComplete:a,disabled:s=!1})=>{const[i,r]=j.useState(Array(t).fill("")),o=j.useRef([]),m=(n,y)=>{var b;if(!/^\d*$/.test(y))return;const c=[...i];c[n]=y.slice(-1),r(c),y&&n<t-1&&((b=o.current[n+1])==null||b.focus());const g=c.join("");g.length===t&&!c.includes("")&&a(g)},l=(n,y)=>{var c;y.key==="Backspace"&&!i[n]&&n>0&&((c=o.current[n-1])==null||c.focus())},d=n=>{var g;n.preventDefault();const y=n.clipboardData.getData("text").replace(/\D/g,"").slice(0,t),c=[...i];for(let b=0;b<y.length;b++)c[b]=y[b];r(c),y.length===t?a(y):(g=o.current[y.length])==null||g.focus()};return e.jsx("div",{className:"flex gap-2 justify-center",dir:"ltr",children:i.map((n,y)=>e.jsx("input",{ref:c=>o.current[y]=c,type:"text",inputMode:"numeric",maxLength:1,value:n,disabled:s,onChange:c=>m(y,c.target.value),onKeyDown:c=>l(y,c),onPaste:d,className:"w-10 h-12 text-center text-xl font-bold border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 dark:text-white disabled:opacity-50"},y))})},ht=({userId:t,onSetupComplete:a})=>{const[s,i]=j.useState("intro"),[r,o]=j.useState(""),[m,l]=j.useState(""),[d,n]=j.useState([]),[y,c]=j.useState(""),g=()=>{const{secret:v,qrCodeUrl:h,backupCodes:f}=gt(t);o(v),l(h||""),n(f),i("qr")},b=v=>{const h=xt(t,v);h.success?a():c(h.message)};return s==="intro"?e.jsxs("div",{className:"p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm",children:[e.jsx("h3",{className:"text-lg font-bold mb-2 dark:text-white",children:"تفعيل التحقق الثنائي"}),e.jsx("p",{className:"text-gray-600 dark:text-gray-300 mb-4",children:"قم بحماية حسابك بإضافة طبقة أمان إضافية. ستحتاج إلى تطبيق مثل Google Authenticator."}),e.jsx("button",{onClick:g,className:"bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 w-full",children:"البدء"})]}):e.jsxs("div",{className:"p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm",children:[e.jsx("h3",{className:"text-lg font-bold mb-4 dark:text-white",children:s==="qr"?"امسح الرمز المربع":"أدخل كود التحقق"}),s==="qr"&&e.jsxs("div",{className:"space-y-4",children:[e.jsx("div",{className:"flex justify-center p-4 bg-white rounded border",children:e.jsxs("div",{className:"text-center",children:[e.jsx("p",{className:"font-mono bg-gray-100 p-2 rounded mb-2",children:r}),e.jsx("p",{className:"text-sm text-gray-500",children:"أدخل هذا المفتاح في تطبيق المصادقة إذا لم يعمل الرمز المربع"})]})}),e.jsxs("div",{className:"bg-yellow-50 p-3 rounded text-sm text-yellow-800 border border-yellow-200",children:[e.jsx("strong",{children:"احتفظ بالأكواد الاحتياطية:"}),e.jsx("div",{className:"grid grid-cols-2 gap-2 mt-2 font-mono",children:d.slice(0,4).map(v=>e.jsx("span",{children:v},v))})]}),e.jsx("button",{onClick:()=>i("verify"),className:"bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 w-full",children:"التالي"})]}),s==="verify"&&e.jsxs("div",{className:"space-y-4",children:[e.jsx(ut,{onComplete:b}),y&&e.jsx("p",{className:"text-red-500 text-sm text-center",children:y})]})]})},z=(t,a)=>A(null,null,function*(){const{jsPDF:s}=yield ke(()=>A(null,null,function*(){const{jsPDF:p}=yield import("./jspdf.es.min-BsawNrML.js").then(u=>u.j);return{jsPDF:p}}),__vite__mapDeps([0,1,2])),i=t.orientation==="landscape",r=new s({orientation:t.orientation||"portrait",unit:"mm",format:t.pageSize||"A4"}),o=i?297:210,m=i?210:297,l=20,d=o-l*2;let n=l;r.setFont("helvetica");const y=()=>{if(r.setDrawColor(15,60,53),r.setLineWidth(.5),r.rect(l-5,l-5,d+10,35),r.setFontSize(18),r.setTextColor(15,60,53),r.text(t.title,o/2,n+8,{align:"center"}),t.subtitle&&(r.setFontSize(12),r.setTextColor(100,100,100),r.text(t.subtitle,o/2,n+16,{align:"center"})),t.headerInfo){r.setFontSize(9),r.setTextColor(80,80,80);let p=n+22;Object.entries(t.headerInfo).forEach(([u,x],k)=>{const w=l+(k%2===0?0:d/2);r.text(`${u}: ${x}`,w,p),k%2===1&&(p+=5)})}n+=40},c=(p,u)=>{const x=m-10;r.setDrawColor(200,200,200),r.setLineWidth(.3),r.line(l,x-5,o-l,x-5),r.setFontSize(8),r.setTextColor(128,128,128),r.text(`${p} / ${u}`,o/2,x,{align:"center"});const k=new Date().toLocaleDateString("ar-SY",{year:"numeric",month:"long",day:"numeric"});r.text(k,l,x),t.footer&&r.text(t.footer,o-l,x,{align:"right"})},g=()=>{t.watermark&&(r.setFontSize(50),r.setTextColor(230,230,230),r.text(t.watermark,o/2,m/2,{align:"center",angle:45}))},b=p=>{const u=Object.entries(p),x=Math.min(u.length,4),k=d/x,w=25;r.setFillColor(248,250,252),r.rect(l,n,d,w,"F"),r.setDrawColor(200,200,200),r.rect(l,n,d,w,"S"),u.forEach(([C,F],R)=>{const E=l+R%x*k+k/2,S=n+8;r.setFontSize(10),r.setTextColor(100,100,100),r.text(C,E,S,{align:"center"}),r.setFontSize(14),r.setTextColor(15,60,53),r.text(String(F),E,S+10,{align:"center"})}),n+=w+10},v=(p,u,x)=>{r.setFontSize(12),r.setTextColor(15,60,53),r.text(p,o/2,n,{align:"center"}),n+=8;const w=d/u.length;r.setFillColor(15,60,53),r.rect(l,n,d,8,"F"),r.setFontSize(9),r.setTextColor(255,255,255);let C=l;u.forEach(F=>{const R=F.width||w,E=F.align==="center"?C+R/2:F.align==="left"?C+2:C+R-2;r.text(F.label,E,n+5.5,{align:F.align||"right"}),C+=R}),n+=8,r.setTextColor(50,50,50),x.forEach((F,R)=>{n>m-30&&(r.addPage(),n=l,g()),R%2===0&&(r.setFillColor(248,250,252),r.rect(l,n,d,7,"F")),r.setDrawColor(220,220,220),r.rect(l,n,d,7,"S"),C=l,u.forEach(E=>{const S=E.width||w;let D=F[E.key];E.format&&(D=E.format(D));const P=E.align==="center"?C+S/2:E.align==="left"?C+2:C+S-2;r.setFontSize(8),r.text(String(D!=null?D:""),P,n+5,{align:E.align||"right"}),C+=S}),n+=7}),n+=10},h=p=>{r.setFontSize(10),r.setTextColor(50,50,50),r.splitTextToSize(p,d).forEach(x=>{n>m-20&&(r.addPage(),n=l,g()),r.text(x,l,n),n+=5}),n+=5};g(),y(),a.summary&&b(a.summary),a.text&&h(a.text),a.tables&&a.tables.forEach(p=>{n>m-50&&(r.addPage(),n=l,g()),v(p.title,p.columns,p.data)});const f=r.getNumberOfPages();for(let p=1;p<=f;p++)r.setPage(p),c(p,f);return r.output("blob")}),pt=(s,...i)=>A(null,[s,...i],function*(t,a={}){const r={New:"جديد",InProgress:"قيد المعالجة",Answered:"تم الرد",Closed:"مغلق"},o=t.reduce((m,l)=>(m[l.status]=(m[l.status]||0)+1,m),{});return z({title:a.title||"تقرير التذاكر",subtitle:"مديرية مالية حلب - نظام الاستعلامات والشكاوى",watermark:"سري",headerInfo:{"تاريخ التقرير":new Date().toLocaleDateString("ar-SY"),"عدد التذاكر":String(t.length),الفترة:a.dateRange?`${a.dateRange.from.toLocaleDateString("ar-SY")} - ${a.dateRange.to.toLocaleDateString("ar-SY")}`:"جميع الفترات"}},{summary:{الإجمالي:t.length,جديد:o.New||0,"قيد المعالجة":o.InProgress||0,مغلق:o.Closed||0},tables:[{title:"قائمة التذاكر",columns:[{key:"id",label:"رقم التذكرة",width:30},{key:"fullName",label:"الاسم",width:40},{key:"department",label:"القسم",width:35},{key:"requestType",label:"النوع",width:30},{key:"status",label:"الحالة",width:25,format:m=>r[m]||m},{key:"createdAt",label:"التاريخ",width:30,format:m=>new Date(m).toLocaleDateString("ar-SY")}],data:t}]})}),bt=t=>A(null,null,function*(){const a=t.reduce((s,i)=>(s[i.role]=(s[i.role]||0)+1,s),{});return z({title:"تقرير الموظفين",subtitle:"مديرية مالية حلب",headerInfo:{"تاريخ التقرير":new Date().toLocaleDateString("ar-SY"),"عدد الموظفين":String(t.length)}},{summary:{الإجمالي:t.length,مدراء:a.مدير||0,موظفين:a.موظف||0},tables:[{title:"قائمة الموظفين",columns:[{key:"username",label:"اسم المستخدم",width:40},{key:"name",label:"الاسم",width:50},{key:"department",label:"القسم",width:50},{key:"role",label:"الدور",width:30}],data:t}]})}),yt=t=>A(null,null,function*(){return z({title:"تقرير الإحصائيات الشهري",subtitle:"مديرية مالية حلب - نظام الاستعلامات والشكاوى",headerInfo:{"تاريخ التقرير":new Date().toLocaleDateString("ar-SY"),الفترة:"آخر 30 يوم"}},{summary:{"إجمالي التذاكر":t.totalTickets,"تذاكر جديدة":t.newTickets,"تذاكر مغلقة":t.closedTickets,"متوسط الاستجابة":t.avgResponseTime},tables:[{title:"الأقسام الأكثر نشاطاً",columns:[{key:"name",label:"القسم",width:120},{key:"count",label:"عدد التذاكر",width:50,align:"center"}],data:t.topDepartments},{title:"البيانات الشهرية",columns:[{key:"month",label:"الشهر",width:120},{key:"count",label:"عدد التذاكر",width:50,align:"center"}],data:t.monthlyData}]})}),ft=({type:t,data:a,onGenerate:s})=>{const[i,r]=j.useState(!1),o=()=>A(null,null,function*(){r(!0);try{let m,l;switch(t){case"tickets":m=yield pt(a),l=`tickets_report_${Date.now()}`;break;case"employees":m=yield bt(a),l=`employees_report_${Date.now()}`;break;case"statistics":m=yield yt(a),l=`statistics_report_${Date.now()}`;break;default:return}const d=URL.createObjectURL(m),n=document.createElement("a");n.href=d,n.download=`${l}.pdf`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(d),s==null||s()}catch(m){console.error("Error generating report:",m)}finally{r(!1)}});return e.jsx("button",{onClick:o,disabled:i,className:"inline-flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium disabled:opacity-50 transition-colors",children:i?e.jsxs(e.Fragment,{children:[e.jsx("span",{className:"animate-spin",children:"⏳"}),e.jsx("span",{children:"جاري الإنشاء..."})]}):e.jsxs(e.Fragment,{children:[e.jsx("span",{children:"📄"}),e.jsx("span",{children:"تصدير PDF"})]})})},xe="internal_messages",jt={low:{label:"منخفضة",color:"gray",icon:"⬇️"},normal:{label:"عادية",color:"blue",icon:"➡️"},high:{label:"مرتفعة",color:"orange",icon:"⬆️"},urgent:{label:"عاجلة",color:"red",icon:"🔴"}},vt=()=>{try{const t=localStorage.getItem(xe);return t?JSON.parse(t):[]}catch(t){return[]}},kt=t=>{const a=$(N({},t),{id:`msg_${Date.now()}_${Math.random().toString(36).slice(2,9)}`,status:"sent",createdAt:new Date().toISOString()}),s=vt();s.unshift(a),localStorage.setItem(xe,JSON.stringify(s));const i={id:`notif_${Date.now()}`,type:"internal_message",title:`رسالة جديدة من ${t.senderName}`,body:t.subject,recipientId:t.recipientId,createdAt:new Date().toISOString(),read:!1},r=JSON.parse(localStorage.getItem("internal_notifications")||"[]");return r.unshift(i),localStorage.setItem("internal_notifications",JSON.stringify(r)),a},wt=({recipients:t,onSend:a,onCancel:s,replyTo:i,currentUser:r})=>{const[o,m]=j.useState((i==null?void 0:i.senderId)||""),[l,d]=j.useState(i?i.subject.startsWith("رد:")?i.subject:`رد: ${i.subject}`:""),[n,y]=j.useState(""),[c,g]=j.useState((i==null?void 0:i.priority)||"normal"),b=()=>{if(!o||!l.trim()||!n.trim())return;const v=t.find(h=>h.id===o);v&&a({senderId:r.id,senderName:r.name,senderRole:r.role,recipientId:v.id,recipientName:v.name,subject:l.trim(),content:n.trim(),priority:c,parentMessageId:i==null?void 0:i.id})};return e.jsxs("div",{className:"bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6",children:[e.jsx("h3",{className:"text-lg font-bold text-gray-800 dark:text-white mb-4",children:i?"رد على الرسالة":"رسالة جديدة"}),e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1",children:"إلى:"}),e.jsxs("select",{value:o,onChange:v=>m(v.target.value),disabled:!!i,className:"w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white disabled:opacity-50",children:[e.jsx("option",{value:"",children:"اختر المستلم"}),t.filter(v=>v.id!==r.id).map(v=>e.jsxs("option",{value:v.id,children:[v.name," ",v.role?`(${v.role})`:""]},v.id))]})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1",children:"الموضوع:"}),e.jsx("input",{type:"text",value:l,onChange:v=>d(v.target.value),placeholder:"موضوع الرسالة",className:"w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1",children:"الأولوية:"}),e.jsx("div",{className:"flex gap-2",children:Object.entries(jt).map(([v,h])=>e.jsxs("button",{onClick:()=>g(v),className:`flex-1 py-2 px-3 rounded-lg text-sm font-medium transition-colors ${c===v?`bg-${h.color}-100 text-${h.color}-700 dark:bg-${h.color}-900/30 dark:text-${h.color}-400 ring-2 ring-${h.color}-500`:"bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"}`,children:[h.icon," ",h.label]},v))})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1",children:"الرسالة:"}),e.jsx("textarea",{value:n,onChange:v=>y(v.target.value),placeholder:"اكتب رسالتك هنا...",rows:6,className:"w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white resize-none"})]}),e.jsxs("div",{className:"flex justify-end gap-3",children:[e.jsx("button",{onClick:s,className:"px-4 py-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors",children:"إلغاء"}),e.jsx("button",{onClick:b,disabled:!o||!l.trim()||!n.trim(),className:"px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed transition-colors",children:"إرسال"})]})]})]})},_="quick_replies",Nt="quick_reply_categories",se=[{id:"general",name:"عام",icon:"📋",color:"blue"},{id:"greeting",name:"ترحيب",icon:"👋",color:"green"},{id:"closing",name:"إغلاق",icon:"✅",color:"teal"},{id:"info",name:"معلومات",icon:"ℹ️",color:"purple"},{id:"followup",name:"متابعة",icon:"🔄",color:"orange"},{id:"rejection",name:"اعتذار",icon:"⚠️",color:"red"}],B=[{id:"default_1",title:"ترحيب",content:`السلام عليكم ورحمة الله وبركاته،

نشكرك على تواصلك مع مديرية مالية حلب.

{محتوى_الرد}

مع أطيب التحيات،
{اسم_الموظف}`,category:"greeting",tags:["ترحيب","بداية"],variables:["محتوى_الرد","اسم_الموظف"],usageCount:0,createdAt:new Date().toISOString(),isGlobal:!0},{id:"default_2",title:"طلب مستندات إضافية",content:`نشكرك على تواصلك معنا.

للتمكن من معالجة طلبك، نرجو منك تزويدنا بالمستندات التالية:
- {المستند_1}
- {المستند_2}

نرجو إرسالها في أقرب وقت ممكن.

مع التقدير.`,category:"info",tags:["مستندات","طلب"],variables:["المستند_1","المستند_2"],usageCount:0,createdAt:new Date().toISOString(),isGlobal:!0},{id:"default_3",title:"إغلاق مع حل",content:`تم معالجة طلبك بنجاح.

{تفاصيل_الحل}

في حال وجود أي استفسارات إضافية، لا تتردد في التواصل معنا.

مع أطيب التمنيات.`,category:"closing",tags:["إغلاق","حل"],variables:["تفاصيل_الحل"],usageCount:0,createdAt:new Date().toISOString(),isGlobal:!0},{id:"default_4",title:"متابعة",content:`تحية طيبة،

نود إعلامك بأن طلبك رقم {رقم_الطلب} قيد المعالجة حالياً.

{تفاصيل_المتابعة}

سنوافيك بالتحديثات قريباً.`,category:"followup",tags:["متابعة","تحديث"],variables:["رقم_الطلب","تفاصيل_المتابعة"],usageCount:0,createdAt:new Date().toISOString(),isGlobal:!0},{id:"default_5",title:"اعتذار عن عدم الاختصاص",content:`نشكرك على تواصلك معنا.

نود إعلامك بأن الموضوع المطروح لا يقع ضمن اختصاص مديرية مالية حلب.

ننصحك بالتوجه إلى {الجهة_المختصة} للحصول على المساعدة المطلوبة.

مع أطيب التمنيات.`,category:"rejection",tags:["اعتذار","تحويل"],variables:["الجهة_المختصة"],usageCount:0,createdAt:new Date().toISOString(),isGlobal:!0}],I=()=>{try{const t=localStorage.getItem(_),a=t?JSON.parse(t):[];return a.length===0?(localStorage.setItem(_,JSON.stringify(B)),B):a}catch(t){return B}},H=()=>{try{const t=localStorage.getItem(Nt);return t?JSON.parse(t):se}catch(t){return se}},ue=t=>{const a=$(N({},t),{id:`qr_${Date.now()}_${Math.random().toString(36).slice(2,9)}`,usageCount:0,createdAt:new Date().toISOString()}),s=I();return s.push(a),localStorage.setItem(_,JSON.stringify(s)),a},he=(t,a)=>{const s=I(),i=s.findIndex(r=>r.id===t);i!==-1&&(s[i]=N(N({},s[i]),a),localStorage.setItem(_,JSON.stringify(s)))},pe=t=>{const a=I().filter(s=>s.id!==t);localStorage.setItem(_,JSON.stringify(a))},re=t=>{const a=I(),s=a.findIndex(i=>i.id===t);s!==-1&&(a[s].usageCount=(a[s].usageCount||0)+1,a[s].lastUsed=new Date().toISOString(),localStorage.setItem(_,JSON.stringify(a)))},ne=(t,a)=>{let s=t;return Object.entries(a).forEach(([i,r])=>{const o=new RegExp(`\\{${i}\\}`,"g");s=s.replace(o,r)}),s},ie=t=>{const a=t.match(/\{([^}]+)\}/g);return a?[...new Set(a.map(s=>s.slice(1,-1)))]:[]},St=(t,a)=>{const s=I(),i=t.toLowerCase();return s.filter(r=>a&&r.category!==a?!1:`${r.title} ${r.content} ${r.tags.join(" ")}`.toLowerCase().includes(i))},Ct=(t=5)=>I().sort((s,i)=>(i.usageCount||0)-(s.usageCount||0)).slice(0,t),$t=({onSelect:t,variables:a={}})=>{const[s,i]=j.useState([]),[r]=j.useState(H()),[o,m]=j.useState(null),[l,d]=j.useState(""),[n,y]=j.useState(!1),[c,g]=j.useState(null),[b,v]=j.useState(a);j.useEffect(()=>{i(I())},[]);const h=j.useMemo(()=>{let u=s;if(o&&(u=u.filter(x=>x.category===o)),l){const x=l.toLowerCase();u=u.filter(k=>k.title.toLowerCase().includes(x)||k.content.toLowerCase().includes(x)||k.tags.some(w=>w.toLowerCase().includes(x)))}return u},[s,o,l]),f=u=>{const x=ie(u.content);x.length>0?(g(u),v(k=>{const w=N({},k);return x.forEach(C=>{w[C]||(w[C]="")}),w}),y(!0)):(re(u.id),t(u.content,u))},p=()=>{if(c){const u=ne(c.content,b);re(c.id),t(u,c),y(!1),g(null)}};return e.jsxs("div",{className:"bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden",children:[e.jsx("div",{className:"p-4 border-b border-gray-200 dark:border-gray-700",children:e.jsx("input",{type:"text",value:l,onChange:u=>d(u.target.value),placeholder:"بحث في الردود السريعة...",className:"w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white"})}),e.jsxs("div",{className:"flex gap-2 p-4 border-b border-gray-200 dark:border-gray-700 overflow-x-auto",children:[e.jsx("button",{onClick:()=>m(null),className:`px-3 py-1.5 rounded-full text-sm whitespace-nowrap transition-colors ${o?"bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300":"bg-blue-600 text-white"}`,children:"الكل"}),r.map(u=>e.jsxs("button",{onClick:()=>m(u.id),className:`px-3 py-1.5 rounded-full text-sm whitespace-nowrap transition-colors ${o===u.id?"bg-blue-600 text-white":"bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300"}`,children:[u.icon," ",u.name]},u.id))]}),e.jsx("div",{className:"max-h-80 overflow-y-auto",children:h.length===0?e.jsx("div",{className:"p-8 text-center text-gray-500 dark:text-gray-400",children:"لا توجد ردود مطابقة"}):e.jsx("div",{className:"divide-y divide-gray-200 dark:divide-gray-700",children:h.map(u=>e.jsxs("button",{onClick:()=>f(u),className:"w-full p-4 text-right hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors",children:[e.jsxs("div",{className:"flex items-center justify-between mb-2",children:[e.jsx("span",{className:"font-medium text-gray-800 dark:text-white",children:u.title}),u.usageCount>0&&e.jsxs("span",{className:"text-xs text-gray-500 dark:text-gray-400",children:["استخدم ",u.usageCount," مرة"]})]}),e.jsxs("p",{className:"text-sm text-gray-600 dark:text-gray-400 line-clamp-2",children:[u.content.substring(0,100),"..."]}),u.tags.length>0&&e.jsx("div",{className:"flex gap-1 mt-2",children:u.tags.slice(0,3).map(x=>e.jsx("span",{className:"px-2 py-0.5 text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded",children:x},x))})]},u.id))})}),n&&c&&e.jsx("div",{className:"fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4",children:e.jsxs("div",{className:"bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-lg p-6",children:[e.jsx("h3",{className:"text-lg font-bold text-gray-800 dark:text-white mb-4",children:"تخصيص المتغيرات"}),e.jsx("div",{className:"space-y-4 mb-6",children:ie(c.content).map(u=>e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1",children:u}),e.jsx("input",{type:"text",value:b[u]||"",onChange:x=>v(k=>$(N({},k),{[u]:x.target.value})),className:"w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white",placeholder:`أدخل ${u}`})]},u))}),e.jsxs("div",{className:"bg-gray-50 dark:bg-gray-700 rounded-lg p-4 mb-4",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2",children:"معاينة:"}),e.jsx("p",{className:"text-sm text-gray-600 dark:text-gray-400 whitespace-pre-wrap",children:ne(c.content,b)})]}),e.jsxs("div",{className:"flex justify-end gap-3",children:[e.jsx("button",{onClick:()=>{y(!1),g(null)},className:"px-4 py-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg",children:"إلغاء"}),e.jsx("button",{onClick:p,className:"px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg",children:"استخدام الرد"})]})]})})]})},Et=({userId:t})=>{const[a,s]=j.useState([]),[i]=j.useState(H()),[r,o]=j.useState(!1),[m,l]=j.useState({}),[d,n]=j.useState(null);j.useEffect(()=>{s(I())},[]);const y=()=>s(I()),c=()=>{!m.title||!m.content||!m.category||(m.id?he(m.id,m):ue({title:m.title,content:m.content,category:m.category,tags:m.tags||[],shortcut:m.shortcut,createdBy:t}),o(!1),l({}),y())},g=h=>{confirm("هل أنت متأكد من حذف هذا الرد السريع؟")&&(pe(h),y())},b=h=>{l(h),o(!0)},v=d?a.filter(h=>h.category===d):a;return e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsx("h2",{className:"text-xl font-bold text-gray-800 dark:text-white",children:"إدارة الردود السريعة"}),e.jsx("button",{onClick:()=>{l({category:"general",tags:[]}),o(!0)},className:"px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium",children:"+ رد جديد"})]}),e.jsxs("div",{className:"flex gap-2 overflow-x-auto pb-2",children:[e.jsxs("button",{onClick:()=>n(null),className:`px-4 py-2 rounded-lg whitespace-nowrap ${d?"bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300":"bg-blue-600 text-white"}`,children:["الكل (",a.length,")"]}),i.map(h=>{const f=a.filter(p=>p.category===h.id).length;return e.jsxs("button",{onClick:()=>n(h.id),className:`px-4 py-2 rounded-lg whitespace-nowrap ${d===h.id?"bg-blue-600 text-white":"bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300"}`,children:[h.icon," ",h.name," (",f,")"]},h.id)})]}),e.jsx("div",{className:"grid gap-4 md:grid-cols-2",children:v.map(h=>e.jsxs("div",{className:"bg-white dark:bg-gray-800 rounded-xl p-4 shadow border border-gray-200 dark:border-gray-700",children:[e.jsxs("div",{className:"flex items-start justify-between mb-2",children:[e.jsx("h3",{className:"font-bold text-gray-800 dark:text-white",children:h.title}),e.jsxs("div",{className:"flex gap-1",children:[e.jsx("button",{onClick:()=>b(h),className:"p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded",children:"✏️"}),e.jsx("button",{onClick:()=>g(h.id),className:"p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30 rounded",children:"🗑️"})]})]}),e.jsx("p",{className:"text-sm text-gray-600 dark:text-gray-400 line-clamp-3 mb-3",children:h.content}),e.jsxs("div",{className:"flex items-center justify-between text-xs text-gray-500",children:[e.jsx("div",{className:"flex gap-1",children:h.tags.slice(0,2).map(f=>e.jsx("span",{className:"px-2 py-0.5 bg-gray-100 dark:bg-gray-700 rounded",children:f},f))}),e.jsxs("span",{children:["استخدم ",h.usageCount," مرة"]})]})]},h.id))}),r&&e.jsx("div",{className:"fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4",children:e.jsxs("div",{className:"bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-lg p-6",children:[e.jsx("h3",{className:"text-lg font-bold text-gray-800 dark:text-white mb-4",children:m.id?"تعديل الرد":"رد جديد"}),e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1",children:"العنوان"}),e.jsx("input",{type:"text",value:m.title||"",onChange:h=>l(f=>$(N({},f),{title:h.target.value})),className:"w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1",children:"التصنيف"}),e.jsx("select",{value:m.category||"",onChange:h=>l(f=>$(N({},f),{category:h.target.value})),className:"w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white",children:i.map(h=>e.jsxs("option",{value:h.id,children:[h.icon," ",h.name]},h.id))})]}),e.jsxs("div",{children:[e.jsxs("label",{className:"block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1",children:["المحتوى",e.jsxs("span",{className:"text-xs text-gray-500 mr-2",children:["(استخدم ","{","اسم_المتغير","}"," للمتغيرات)"]})]}),e.jsx("textarea",{value:m.content||"",onChange:h=>l(f=>$(N({},f),{content:h.target.value})),rows:6,className:"w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1",children:"الوسوم (مفصولة بفاصلة)"}),e.jsx("input",{type:"text",value:(m.tags||[]).join(", "),onChange:h=>l(f=>$(N({},f),{tags:h.target.value.split(",").map(p=>p.trim()).filter(Boolean)})),className:"w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white"})]})]}),e.jsxs("div",{className:"flex justify-end gap-3 mt-6",children:[e.jsx("button",{onClick:()=>{o(!1),l({})},className:"px-4 py-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg",children:"إلغاء"}),e.jsx("button",{onClick:c,disabled:!m.title||!m.content,className:"px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg disabled:opacity-50",children:"حفظ"})]})]})})]})},Ft=t=>{const[a,s]=j.useState([]);j.useEffect(()=>{const m=I();s(m)},[t]);const i=j.useMemo(()=>Ct(5),[a]),r=H(),o=j.useCallback(()=>{const m=I();s(m)},[t]);return{replies:a,mostUsed:i,categories:r,refresh:o,add:ue,update:he,remove:pe,search:St}},L=[{id:"offline",title:"وضع عدم الاتصال",icon:e.jsx(le,{}),description:"العمل بدون إنترنت مع مزامنة تلقائية"},{id:"export",title:"تصدير البيانات",icon:e.jsx(M,{}),description:"تصدير بصيغ CSV, JSON, Excel"},{id:"charts",title:"المخططات التفاعلية",icon:e.jsx(Re,{}),description:"رسوم بيانية متنوعة وتفاعلية"},{id:"search",title:"البحث المتقدم",icon:e.jsx(Oe,{}),description:"بحث مع فلاتر متعددة"},{id:"theme",title:"الثيمات والألوان",icon:e.jsx(_e,{}),description:"تخصيص المظهر والألوان"},{id:"print",title:"الطباعة الاحترافية",icon:e.jsx(oe,{}),description:"طباعة محسّنة للتذاكر والتقارير"},{id:"compress",title:"ضغط الصور",icon:e.jsx(Le,{}),description:"ضغط الصور قبل الرفع"},{id:"2fa",title:"التحقق الثنائي",icon:e.jsx(Te,{}),description:"طبقة أمان إضافية"},{id:"activity",title:"سجل النشاطات",icon:e.jsx(Me,{}),description:"تتبع جميع العمليات"},{id:"pdf",title:"تقارير PDF",icon:e.jsx(J,{}),description:"تقارير PDF احترافية"},{id:"dashboard",title:"لوحة إحصائيات",icon:e.jsx(ze,{}),description:"إحصائيات متقدمة ومخططات"},{id:"messages",title:"الرسائل الداخلية",icon:e.jsx(Pe,{}),description:"نظام مراسلة بين الموظفين"},{id:"sounds",title:"أصوات الإشعارات",icon:e.jsx(Ue,{}),description:"تنبيهات صوتية قابلة للتخصيص"},{id:"replies",title:"الردود السريعة",icon:e.jsx(We,{}),description:"قوالب جاهزة للردود"},{id:"sla",title:"تتبع الاستجابة",icon:e.jsx(Be,{}),description:"مراقبة أوقات الرد وSLA"}],Dt=()=>{const[t,a]=j.useState(de),s=["الإدارة","المالية","الضرائب","الخدمات"];return e.jsx(Ze,{filters:t,onFiltersChange:a,departments:s,placeholder:"ابحث في التذاكر..."})},Ot=()=>{var f,p,u,x;const t=j.useContext(we),[a,s]=j.useState("offline"),[i,r]=j.useState(null),[o,m]=j.useState(qe()),[l,d]=j.useState(X().length),n=Ne(),{replies:y}=Ft(),{metrics:c}=Se();j.useEffect(()=>Ve(w=>{m(w),d(X().length)}),[]);const g=(k,w="success")=>{r({message:k,type:w}),w==="success"?n.playSuccess():w==="error"&&n.playError(),setTimeout(()=>r(null),3e3)};j.useEffect(()=>{var k;Ce("ticket_view","زيارة صفحة الميزات المتقدمة",{userId:(k=t==null?void 0:t.currentEmployee)==null?void 0:k.username,severity:"info"})},[]);const b=[{label:"جديد",value:45,color:"#3B82F6"},{label:"قيد المعالجة",value:32,color:"#F59E0B"},{label:"تم الرد",value:78,color:"#10B981"},{label:"مغلق",value:125,color:"#6B7280"}],v=[{label:"يناير",value:65},{label:"فبراير",value:78},{label:"مارس",value:90},{label:"أبريل",value:81},{label:"مايو",value:95},{label:"يونيو",value:110}],h=()=>{var k,w,C,F,R,E;switch(a){case"offline":return e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{className:"flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[o?e.jsx(Je,{className:"text-2xl text-green-500"}):e.jsx(le,{className:"text-2xl text-red-500"}),e.jsxs("div",{children:[e.jsx("h3",{className:"font-bold dark:text-white",children:o?"متصل بالإنترنت":"غير متصل"}),e.jsx("p",{className:"text-sm text-gray-500",children:l>0?`${l} عملية معلقة`:"لا توجد عمليات معلقة"})]})]}),e.jsx(O,{onClick:()=>g("تمت المزامنة","success"),disabled:l===0,children:"مزامنة الآن"})]}),e.jsx("div",{className:`p-4 rounded-lg ${o?"bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-300":"bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300"}`,children:o?"✓ متصل بالإنترنت - جميع البيانات محدثة":"⚠ غير متصل - العمليات ستحفظ محلياً"}),e.jsx("p",{className:"text-gray-600 dark:text-gray-400",children:"يمكنك متابعة العمل حتى بدون اتصال بالإنترنت. سيتم حفظ جميع العمليات محلياً ومزامنتها تلقائياً عند عودة الاتصال."})]});case"export":return e.jsxs("div",{className:"space-y-6",children:[e.jsx("p",{className:"text-gray-600 dark:text-gray-400",children:"تصدير بيانات التذاكر بصيغ متعددة"}),e.jsxs("div",{className:"grid grid-cols-3 gap-4",children:[e.jsxs(O,{onClick:()=>{const S=(t==null?void 0:t.tickets)||[];Qe(S,"tickets",[{key:"id",label:"الرقم"},{key:"fullName",label:"الاسم"},{key:"department",label:"القسم"},{key:"status",label:"الحالة"}]),g("تم تصدير CSV بنجاح")},className:"flex items-center justify-center gap-2",children:[e.jsx(M,{})," CSV"]}),e.jsxs(O,{onClick:()=>{He((t==null?void 0:t.tickets)||[],"tickets"),g("تم تصدير JSON بنجاح")},className:"flex items-center justify-center gap-2",children:[e.jsx(M,{})," JSON"]}),e.jsxs(O,{onClick:()=>{const S=(t==null?void 0:t.tickets)||[];Ge(S,"tickets",[{key:"id",label:"الرقم"},{key:"fullName",label:"الاسم"},{key:"department",label:"القسم"},{key:"status",label:"الحالة"}]),g("تم تصدير Excel بنجاح")},className:"flex items-center justify-center gap-2",children:[e.jsx(M,{})," Excel"]})]})]});case"charts":return e.jsxs("div",{className:"space-y-8",children:[e.jsxs("div",{className:"grid md:grid-cols-2 gap-6",children:[e.jsxs("div",{children:[e.jsx("h3",{className:"font-bold mb-4 dark:text-white",children:"مخطط دائري"}),e.jsx(Z,{data:b,size:200})]}),e.jsxs("div",{children:[e.jsx("h3",{className:"font-bold mb-4 dark:text-white",children:"مخطط حلقي"}),e.jsx(Xe,{data:b,size:200})]})]}),e.jsxs("div",{children:[e.jsx("h3",{className:"font-bold mb-4 dark:text-white",children:"مخطط أعمدة"}),e.jsx(ee,{data:b,height:200})]}),e.jsxs("div",{children:[e.jsx("h3",{className:"font-bold mb-4 dark:text-white",children:"مخطط خطي"}),e.jsx(Ke,{data:v,height:200})]})]});case"search":return e.jsxs("div",{className:"space-y-6",children:[e.jsx("p",{className:"text-gray-600 dark:text-gray-400",children:"البحث المتقدم مع فلاتر متعددة للتذاكر والبيانات"}),e.jsx(Dt,{})]});case"theme":return e.jsx(Ie,{});case"print":return e.jsxs("div",{className:"space-y-6",children:[e.jsx("p",{className:"text-gray-600 dark:text-gray-400",children:"طباعة محسّنة مع تنسيق احترافي للتذاكر والتقارير"}),e.jsxs("div",{className:"flex gap-4",children:[e.jsxs(O,{onClick:()=>{me(),window.print(),g("جاري الطباعة...")},className:"flex items-center gap-2",children:[e.jsx(oe,{})," طباعة هذه الصفحة"]}),e.jsxs(O,{onClick:()=>{et({id:"T-2024-001",fullName:"أحمد محمد",nationalId:"12345678901",department:"المالية",requestType:"شكوى",status:"New",message:"تفاصيل الشكوى...",createdAt:new Date}),g("جاري طباعة التذكرة...")},variant:"secondary",className:"flex items-center gap-2",children:[e.jsx(J,{})," طباعة تذكرة نموذجية"]})]})]});case"compress":return e.jsx("div",{className:"space-y-6",children:e.jsx(rt,{onCompress:S=>{g(`تم ضغط ${S.length} صورة بنجاح`)},maxFiles:5})});case"2fa":return e.jsx("div",{className:"space-y-6",children:e.jsx(ht,{userId:((k=t==null?void 0:t.currentEmployee)==null?void 0:k.username)||"demo_user",onSetupComplete:()=>g("تم تفعيل التحقق الثنائي بنجاح")})});case"activity":return e.jsx(Ae,{limit:50});case"pdf":return e.jsxs("div",{className:"space-y-6",children:[e.jsx(ft,{type:"tickets",data:(t==null?void 0:t.tickets)||[],onGenerate:()=>g("تم إنشاء التقرير بنجاح")}),e.jsxs(O,{onClick:()=>A(null,null,function*(){var S;try{const D=yield z({title:"تقرير التذاكر",subtitle:"نظام الاستعلامات والشكاوى"},{summary:{"عدد التذاكر":((S=t==null?void 0:t.tickets)==null?void 0:S.length)||0}}),P=URL.createObjectURL(D),U=document.createElement("a");U.href=P,U.download="report.pdf",U.click(),g("تم إنشاء التقرير بنجاح")}catch(D){g("فشل في إنشاء التقرير","error")}}),className:"flex items-center gap-2",children:[e.jsx(J,{})," إنشاء تقرير PDF"]})]});case"dashboard":return e.jsxs("div",{className:"space-y-6",children:[e.jsx("p",{className:"text-gray-600 dark:text-gray-400",children:"لوحة إحصائيات متقدمة مع مخططات تفاعلية"}),e.jsxs("div",{className:"grid md:grid-cols-2 gap-6",children:[e.jsxs("div",{children:[e.jsx("h3",{className:"font-bold mb-4 dark:text-white",children:"توزيع التذاكر حسب الحالة"}),e.jsx(Z,{data:b,size:200})]}),e.jsxs("div",{children:[e.jsx("h3",{className:"font-bold mb-4 dark:text-white",children:"التذاكر الشهرية"}),e.jsx(ee,{data:b,height:200})]})]})]});case"messages":return e.jsxs("div",{className:"space-y-6",children:[e.jsx("p",{className:"text-gray-600 dark:text-gray-400",children:"نظام الرسائل الداخلية بين الموظفين"}),e.jsx(wt,{recipients:[{id:"admin",name:"المدير العام",role:"مدير"},{id:"finance1",name:"موظف المالية",role:"موظف"}],currentUser:{id:((w=t==null?void 0:t.currentEmployee)==null?void 0:w.username)||"current",name:((C=t==null?void 0:t.currentEmployee)==null?void 0:C.name)||"المستخدم الحالي",role:(F=t==null?void 0:t.currentEmployee)==null?void 0:F.role},onSend:S=>{kt(S),g("تم إرسال الرسالة بنجاح")},onCancel:()=>{}})]});case"sounds":return e.jsx(De,{});case"replies":return e.jsxs("div",{className:"space-y-6",children:[e.jsx("h3",{className:"font-bold dark:text-white",children:"اختيار رد سريع"}),e.jsx($t,{onSelect:(S,D)=>{g(`تم اختيار: ${D.title}`)}}),e.jsx("hr",{className:"dark:border-gray-700"}),e.jsx("h3",{className:"font-bold dark:text-white",children:"إدارة الردود"}),e.jsx(Et,{userId:(R=t==null?void 0:t.currentEmployee)==null?void 0:R.username})]});case"sla":return e.jsxs("div",{className:"space-y-6",children:[e.jsx(Ee,{}),(E=t==null?void 0:t.tickets)==null?void 0:E.slice(0,3).map(S=>e.jsxs("div",{className:"flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg",children:[e.jsx("span",{className:"font-medium dark:text-white",children:S.id}),e.jsx(Fe,{ticketId:S.id,showDetails:!0})]},S.id))]});default:return e.jsx("div",{children:"اختر ميزة من القائمة"})}};return e.jsxs("div",{className:"min-h-screen py-8",children:[i&&e.jsx("div",{className:`fixed top-4 left-1/2 transform -translate-x-1/2 z-50 px-6 py-3 rounded-lg shadow-lg ${i.type==="success"?"bg-green-500":i.type==="error"?"bg-red-500":"bg-blue-500"} text-white`,children:i.message}),e.jsxs("div",{className:"container mx-auto px-4",children:[e.jsx("div",{className:"text-center mb-8",children:e.jsx("h1",{className:"text-3xl font-bold text-gray-800 dark:text-white",children:"الميزات المتقدمة"})}),e.jsx("div",{className:"grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 mb-8",children:L.map(k=>e.jsxs("button",{onClick:()=>s(k.id),className:`p-4 rounded-xl transition-all text-right ${a===k.id?"bg-blue-600 text-white shadow-lg scale-105":"bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:shadow-md hover:scale-102 border border-gray-200 dark:border-gray-700"}`,children:[e.jsx("div",{className:"text-2xl mb-2",children:k.icon}),e.jsx("div",{className:"font-medium text-sm",children:k.title})]},k.id))}),e.jsxs($e,{className:"p-6",children:[e.jsxs("div",{className:"flex items-center justify-between mb-6",children:[e.jsxs("h2",{className:"text-xl font-bold text-gray-800 dark:text-white flex items-center gap-2",children:[(f=L.find(k=>k.id===a))==null?void 0:f.icon,(p=L.find(k=>k.id===a))==null?void 0:p.title]}),e.jsx("span",{className:"text-sm text-gray-500 dark:text-gray-400",children:(u=L.find(k=>k.id===a))==null?void 0:u.description})]}),h()]}),e.jsxs("div",{className:"mt-8 grid grid-cols-2 md:grid-cols-4 gap-4",children:[e.jsxs("div",{className:"bg-white dark:bg-gray-800 rounded-xl p-4 text-center shadow",children:[e.jsx("div",{className:"text-3xl font-bold text-blue-600",children:L.length}),e.jsx("div",{className:"text-sm text-gray-500",children:"ميزة متوفرة"})]}),e.jsxs("div",{className:"bg-white dark:bg-gray-800 rounded-xl p-4 text-center shadow",children:[e.jsx("div",{className:"text-3xl font-bold text-green-600",children:y.length}),e.jsx("div",{className:"text-sm text-gray-500",children:"رد سريع"})]}),e.jsxs("div",{className:"bg-white dark:bg-gray-800 rounded-xl p-4 text-center shadow",children:[e.jsxs("div",{className:"text-3xl font-bold text-purple-600",children:[((x=c==null?void 0:c.slaCompliance)==null?void 0:x.toFixed(0))||100,"%"]}),e.jsx("div",{className:"text-sm text-gray-500",children:"التزام SLA"})]}),e.jsxs("div",{className:"bg-white dark:bg-gray-800 rounded-xl p-4 text-center shadow",children:[e.jsx("div",{className:"text-3xl font-bold text-orange-600",children:o?"✓":"✗"}),e.jsx("div",{className:"text-sm text-gray-500",children:"حالة الاتصال"})]})]})]})]})};export{Ot as default};
