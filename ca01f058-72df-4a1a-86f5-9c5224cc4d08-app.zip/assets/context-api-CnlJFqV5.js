import{C as t}from"./trace-api-hm6yzyuZ.js";var o=t.getInstance();export{o as c};
