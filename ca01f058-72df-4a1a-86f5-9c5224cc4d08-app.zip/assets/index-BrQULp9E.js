import{h as r}from"./index-BkIQX736.js";var a=r();export{a as r};
