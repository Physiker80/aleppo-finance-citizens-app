var L=(e,r,p)=>new Promise((h,i)=>{var c=a=>{try{t(p.next(a))}catch(o){i(o)}},l=a=>{try{t(p.throw(a))}catch(o){i(o)}},t=a=>a.done?h(a.value):Promise.resolve(a.value).then(c,l);t((p=p.apply(e,r)).next())});import{Q as x,T as F,aB as q,g as Q,s as Z,a as H,b as J,q as K,p as X,_ as g,l as z,c as Y,E as ee,I as te,a4 as ae,d as re,y as ne,F as ie}from"./Mermaid-BXUYMGcD.js";import{p as se}from"./chunk-4BX2VUAB-DbCCTa5Y.js";import{p as le}from"./treemap-KMMF4GRG-Bi0_Ofl5.js";import"./transform-DwCok-mJ.js";import{d as W}from"./arc-DnnNPbJP.js";import{o as oe}from"./ordinal-Cboi1Yqb.js";import"./index-BkIQX736.js";import"./purify.es-h52jTgpa.js";import"./min-Dg-SJUil.js";import"./_baseUniq-DIomVQzV.js";import"./init-Gi6I4Gst.js";function ce(e,r){return r<e?-1:r>e?1:r>=e?0:NaN}function pe(e){return e}function ue(){var e=pe,r=ce,p=null,h=x(0),i=x(F),c=x(0);function l(t){var a,o=(t=q(t)).length,d,S,y=0,u=new Array(o),s=new Array(o),m=+h.apply(this,arguments),w=Math.min(F,Math.max(-F,i.apply(this,arguments)-m)),v,$=Math.min(Math.abs(w)/o,c.apply(this,arguments)),T=$*(w<0?-1:1),f;for(a=0;a<o;++a)(f=s[u[a]=a]=+e(t[a],a,t))>0&&(y+=f);for(r!=null?u.sort(function(D,C){return r(s[D],s[C])}):p!=null&&u.sort(function(D,C){return p(t[D],t[C])}),a=0,S=y?(w-o*T)/y:0;a<o;++a,m=v)d=u[a],f=s[d],v=m+(f>0?f*S:0)+T,s[d]={data:t[d],index:a,value:f,startAngle:m,endAngle:v,padAngle:$};return s}return l.value=function(t){return arguments.length?(e=typeof t=="function"?t:x(+t),l):e},l.sortValues=function(t){return arguments.length?(r=t,p=null,l):r},l.sort=function(t){return arguments.length?(p=t,r=null,l):p},l.startAngle=function(t){return arguments.length?(h=typeof t=="function"?t:x(+t),l):h},l.endAngle=function(t){return arguments.length?(i=typeof t=="function"?t:x(+t),l):i},l.padAngle=function(t){return arguments.length?(c=typeof t=="function"?t:x(+t),l):c},l}var ge=ie.pie,G={sections:new Map,showData:!1},E=G.sections,N=G.showData,de=structuredClone(ge),fe=g(()=>structuredClone(de),"getConfig"),me=g(()=>{E=new Map,N=G.showData,ne()},"clear"),he=g(({label:e,value:r})=>{if(r<0)throw new Error(`"${e}" has invalid value: ${r}. Negative values are not allowed in pie charts. All slice values must be >= 0.`);E.has(e)||(E.set(e,r),z.debug(`added new section: ${e}, with value: ${r}`))},"addSection"),ve=g(()=>E,"getSections"),ye=g(e=>{N=e},"setShowData"),xe=g(()=>N,"getShowData"),_={getConfig:fe,clear:me,setDiagramTitle:X,getDiagramTitle:K,setAccTitle:J,getAccTitle:H,setAccDescription:Z,getAccDescription:Q,addSection:he,getSections:ve,setShowData:ye,getShowData:xe},Se=g((e,r)=>{se(e,r),r.setShowData(e.showData),e.sections.map(r.addSection)},"populateDb"),we={parse:g(e=>L(null,null,function*(){const r=yield le("pie",e);z.debug(r),Se(r,_)}),"parse")},Ae=g(e=>`
  .pieCircle{
    stroke: ${e.pieStrokeColor};
    stroke-width : ${e.pieStrokeWidth};
    opacity : ${e.pieOpacity};
  }
  .pieOuterCircle{
    stroke: ${e.pieOuterStrokeColor};
    stroke-width: ${e.pieOuterStrokeWidth};
    fill: none;
  }
  .pieTitleText {
    text-anchor: middle;
    font-size: ${e.pieTitleTextSize};
    fill: ${e.pieTitleTextColor};
    font-family: ${e.fontFamily};
  }
  .slice {
    font-family: ${e.fontFamily};
    fill: ${e.pieSectionTextColor};
    font-size:${e.pieSectionTextSize};
    // fill: white;
  }
  .legend text {
    fill: ${e.pieLegendTextColor};
    font-family: ${e.fontFamily};
    font-size: ${e.pieLegendTextSize};
  }
`,"getStyles"),De=Ae,Ce=g(e=>{const r=[...e.values()].reduce((i,c)=>i+c,0),p=[...e.entries()].map(([i,c])=>({label:i,value:c})).filter(i=>i.value/r*100>=1).sort((i,c)=>c.value-i.value);return ue().value(i=>i.value)(p)},"createPieArcs"),$e=g((e,r,p,h)=>{z.debug(`rendering pie chart
`+e);const i=h.db,c=Y(),l=ee(i.getConfig(),c.pie),t=40,a=18,o=4,d=450,S=d,y=te(r),u=y.append("g");u.attr("transform","translate("+S/2+","+d/2+")");const{themeVariables:s}=c;let[m]=ae(s.pieOuterStrokeWidth);m!=null||(m=2);const w=l.textPosition,v=Math.min(S,d)/2-t,$=W().innerRadius(0).outerRadius(v),T=W().innerRadius(v*w).outerRadius(v*w);u.append("circle").attr("cx",0).attr("cy",0).attr("r",v+m/2).attr("class","pieOuterCircle");const f=i.getSections(),D=Ce(f),C=[s.pie1,s.pie2,s.pie3,s.pie4,s.pie5,s.pie6,s.pie7,s.pie8,s.pie9,s.pie10,s.pie11,s.pie12];let b=0;f.forEach(n=>{b+=n});const I=D.filter(n=>(n.data.value/b*100).toFixed(0)!=="0"),M=oe(C);u.selectAll("mySlices").data(I).enter().append("path").attr("d",$).attr("fill",n=>M(n.data.label)).attr("class","pieCircle"),u.selectAll("mySlices").data(I).enter().append("text").text(n=>(n.data.value/b*100).toFixed(0)+"%").attr("transform",n=>"translate("+T.centroid(n)+")").style("text-anchor","middle").attr("class","slice"),u.append("text").text(i.getDiagramTitle()).attr("x",0).attr("y",-400/2).attr("class","pieTitleText");const O=[...f.entries()].map(([n,A])=>({label:n,value:A})),k=u.selectAll(".legend").data(O).enter().append("g").attr("class","legend").attr("transform",(n,A)=>{const R=a+o,V=R*O.length/2,U=12*a,j=A*R-V;return"translate("+U+","+j+")"});k.append("rect").attr("width",a).attr("height",a).style("fill",n=>M(n.label)).style("stroke",n=>M(n.label)),k.append("text").attr("x",a+o).attr("y",a-o).text(n=>i.getShowData()?`${n.label} [${n.value}]`:n.label);const B=Math.max(...k.selectAll("text").nodes().map(n=>{var A;return(A=n==null?void 0:n.getBoundingClientRect().width)!=null?A:0})),P=S+t+a+o+B;y.attr("viewBox",`0 0 ${P} ${d}`),re(y,d,P,l.useMaxWidth)},"draw"),Te={draw:$e},Le={parser:we,db:_,renderer:Te,styles:De};export{Le as diagram};
